#!/bin/bash

## This shell command generates statistics of FASP files in the ./log/FILES.

wc -l ./base/include/*.h ./base/src/*.inl ./base/src/*.c > ./log/FILES


